export type Doctor = {
    id: string;
    name: string;
    specialty: string;
    image: string;
};